<?php

return [
    'header' => [
        'top_bar_message' => 'ارسال رایگان برای سفارشات بالای ۵۰ دلار | پشتیبانی | مکان‌یاب فروشگاه‌ها',
        'search_placeholder' => 'جستجو برای یک محصول',
    ],

    'footer' => [
        'account' => 'حساب کاربری',
        'my_account' => 'حساب من',
        'wishlist' => 'لیست علاقه‌مندی‌ها',
        'pages' => 'صفحات',
        'privacy_policy' => 'سیاست حفظ حریم خصوصی',
        'terms_of_service' => 'شرایط خدمات',
        'follow_us' => 'ما را دنبال کنید',
        'footer_logo_alt' => 'لوگوی پاورقی Velstore',
        'copyright' => '© ۲۰۲۵ نسخه نمایشی Velstore. تمامی حقوق محفوظ است.',
        'powered_by' => 'قدرت گرفته از Velstore Labs',
    ],

    'home' => [
        'banner_text' => 'بزرگ‌ترین مجموعه از کتانی‌ها، کفش‌ها و ترندهای پوشاک خیابانی را کشف کنید.',
        'shop_now' => 'اکنون خرید کنید',
        'explore_popular_categories' => 'دسته‌های محبوب را بررسی کنید',
        'trending_products' => 'محصولات پرطرفدار',
        'reviews' => 'نظرات',
        'product_name_not_available' => 'نام محصول در دسترس نیست',
        'featured_products' => 'محصولات ویژه',
        'view_all' => 'مشاهده همه',
        // Why Choose Us section
        'why_choose_us' => 'چرا ما؟',
        'fast_delivery_title' => 'تحویل سریع',
        'fast_delivery_text' => 'ما سفارش‌های شما را سریع و ایمن تا درب منزل تحویل می‌دهیم.',
        'customer_support_title' => 'پشتیبانی مشتری',
        'customer_support_text' => 'تیم پشتیبانی ما همیشه و در هر زمان برای کمک در دسترس است.',
        'trusted_worldwide_title' => 'مورد اعتماد در سراسر جهان',
        'trusted_worldwide_text' => 'هزاران مشتری راضی، نظرات عالی و امتیازات بالا.',
        'ten_years_services_title' => '۱۰ سال خدمات',
        'ten_years_services_text' => 'بیش از ۱۰ سال خدمات قابل اعتماد همراه با کیفیت و رضایت.',
    ],

    'product_detail' => [
        'color' => 'رنگ',
        'size' => 'اندازه',
        'home' => 'خانه',
        'in_stock' => 'موجود در انبار',
        'out_of_stock' => 'ناموجود',
        'customer_reviews' => 'نظرات مشتریان',
        'no_reviews' => 'هنوز نظری برای این محصول ثبت نشده است.',
        'no_review_text' => 'هیچ متنی نوشته نشده است.',
        'average_rating' => 'میانگین امتیاز',
        'days_ago' => '{1} :days روز پیش|[2,*] :days روز پیش',
        'description' => 'توضیحات',
        'reviews' => 'نظرات',
        'add_to_cart' => 'افزودن به سبد خرید',
        'increase_quantity' => 'افزایش تعداد',
        'decrease_quantity' => 'کاهش تعداد',
        'selected_variant_not' => 'گزینه انتخاب‌شده موجود نیست.',
        'fetch_variant_failed' => 'قیمت گزینه قابل دریافت نیست.',
        'ajax_error' => 'مشکلی پیش آمد. لطفاً دوباره تلاش کنید.',
        'currency_symbol' => 'واحد پول',
        'cart_success' => 'محصول با موفقیت به سبد خرید اضافه شد.',
        'cart_update_error' => 'امکان به‌روزرسانی سبد خرید وجود ندارد. لطفاً دوباره تلاش کنید.',
        'submit_review_title' => 'ارسال نظر شما',
        'review_optional' => 'نظر (اختیاری)',
        'submit_review_btn' => 'ارسال نظر',
        'please' => 'لطفاً',
        'login' => 'ورود',
        'customer' => 'مشتری',
        'submit' => 'برای ارسال نظر.',
        'no_reviews_yet' => 'هنوز نظری برای این محصول ثبت نشده است.',
        'no_review_text' => 'نظری نوشته نشده است.',
        'day' => 'روز',
        'days' => 'روز', // In Persian plural form stays same but context handles it
        'ago' => 'پیش',
        'average_rating' => 'میانگین امتیاز',
        'variant_not_available' => 'گزینه انتخاب‌شده موجود نمی‌باشد.',
        'something_wrong' => 'مشکلی پیش آمده است. لطفاً دوباره تلاش کنید.',
        'added_to_wishlist' => 'به علاقه‌مندی‌ها اضافه شد ❤️',
        'removed_from_wishlist' => 'از علاقه‌مندی‌ها حذف شد 💔',
        'login_to_wishlist' => 'لطفاً برای مدیریت علاقه‌مندی‌ها وارد شوید.',
        'review_already_submitted' => 'شما قبلاً برای این محصول نظر داده‌اید.',
        'review_success' => 'متشکریم! نظر شما ثبت و منتشر شد.',
    ],

    'shop' => [
        'brands' => 'برندها',
        'categories' => 'دسته‌بندی‌ها',
        'price' => 'قیمت',
        'colors' => 'رنگ‌ها',
        'size' => 'سایز',
        'red' => 'قرمز',
        'black' => 'مشکی',
        'M' => 'متوسط',
        'L' => 'بزرگ',
        'price_range' => ':min - :max',
        'added_to_cart' => 'محصول با موفقیت به سبد خرید اضافه شد!',
    ],

    'cart' => [

        // Breadcrumb
        'breadcrumb_home' => 'صفحه اصلی',
        'breadcrumb_cart' => 'سبد خرید',

        // Cart messages
        'empty_cart' => 'سبد خرید شما خالی است.',
        'continue_shopping' => 'ادامه خرید',
        'update_cart' => 'به‌روزرسانی سبد خرید',

        // Table headings
        'product' => 'محصول',
        'price' => 'قیمت',
        'quantity' => 'تعداد',
        'subtotal' => 'جمع جزء',

        // Cart totals section
        'cart_totals' => 'جمع کل سبد خرید',
        'subtotal_label' => 'جمع جزء',
        'discount_label' => 'تخفیف',
        'total_label' => 'جمع کل',
        'proceed_to_checkout' => 'ادامه به پرداخت',

        // Coupon section
        'coupon_heading' => 'کد تخفیف',
        'coupon_placeholder' => 'کد تخفیف را وارد کنید',
        'apply_coupon' => 'اعمال کد تخفیف',
        'remove_coupon' => 'حذف کد تخفیف',

        // Toast messages
        'coupon_applied' => 'کد تخفیف با موفقیت اعمال شد!',
        'coupon_removed' => 'کد تخفیف با موفقیت حذف شد!',
        'cart_updated' => 'سبد خرید با موفقیت به‌روزرسانی شد!',
        'item_removed' => 'محصول از سبد خرید حذف شد.',
        'error_occurred' => 'مشکلی پیش آمد. لطفاً دوباره تلاش کنید.',
        'product_removed' => 'محصول از سبد خرید حذف شد.',
    ],

    'checkout' => [

        // Breadcrumb
        'breadcrumb_home' => 'صفحه اصلی',
        'breadcrumb_category' => 'هدفون',
        'breadcrumb_checkout' => 'تسویه حساب',

        // Section titles
        'shipping_information' => 'اطلاعات ارسال',
        'contact_information' => 'اطلاعات تماس',
        'payment_method' => 'روش پرداخت',
        'order_summary' => 'خلاصه سفارش',

        // Shipping form placeholders
        'first_name' => 'نام',
        'last_name' => 'نام خانوادگی',
        'address' => 'آدرس',
        'suite' => 'واحد / طبقه',
        'select_country' => 'انتخاب کشور',
        'city' => 'شهر',
        'select_state' => 'انتخاب استان',
        'zipcode' => 'کد پستی',
        'use_as_billing' => 'استفاده به عنوان آدرس صورتحساب',

        // Contact form placeholders
        'email' => 'ایمیل',
        'phone' => 'شماره تلفن',

        // Payment
        'select_payment' => 'روش پرداخت را انتخاب کنید',
        'stripe' => 'استرایپ',
        'paypal' => 'پی‌پال',

        // Summary labels
        'subtotal' => 'جمع جزء',
        'shipping' => 'هزینه ارسال',
        'shipping_info' => 'برای مشاهده هزینه ارسال، آدرس خود را وارد کنید',
        'total' => 'جمع کل',
        'proceed' => 'ادامه',
        'place_order' => 'ثبت سفارش',

        // Toast / messages
        'order_success' => 'سفارش شما با موفقیت ثبت شد!',
        'order_failed' => 'خطایی رخ داد. لطفاً دوباره تلاش کنید.',
        'payment_required' => 'لطفاً قبل از ادامه، روش پرداخت را انتخاب کنید.',
        'paypal_instructions' => 'لطفاً پرداخت خود را با استفاده از دکمه پی‌پال تکمیل کنید.',
    ],

    'profile' => [
        'title' => 'ویرایش پروفایل',
        'choose_file' => 'انتخاب فایل',
        'name' => 'نام',
        'email' => 'ایمیل',
        'phone' => 'تلفن',
        'address' => 'آدرس',
        'current_password' => 'رمز عبور فعلی',
        'new_password' => 'رمز عبور جدید',
        'confirm_new_password' => 'تأیید رمز عبور جدید',
        'save' => 'ذخیره',
        'success' => 'موفقیت',
        'profile_updated' => 'پروفایل با موفقیت به‌روزرسانی شد.',
    ],

    'category' => [
        'home' => 'خانه',
        'min_price' => 'حداقل قیمت',
        'max_price' => 'حداکثر قیمت',
        'sort_by' => 'مرتب‌سازی بر اساس',
        'newest' => 'جدیدترین',
        'price_low_high' => 'قیمت: کم به زیاد',
        'price_high_low' => 'قیمت: زیاد به کم',
        'top_rated' => 'بالاترین امتیاز',
        'filter' => 'فیلتر',
        'reviews' => 'نظرات',
        'product_name_not_available' => 'نام محصول موجود نیست',
        'no_products_found' => 'هیچ محصولی در این دسته یافت نشد.',
        'add_to_cart_success' => 'محصول با موفقیت به سبد خرید اضافه شد!',
    ],

    'wishlist' => [
        'title' => 'لیست علاقه‌مندی‌های من',
        'empty' => 'لیست علاقه‌مندی‌های شما خالی است.',
        'reviews' => 'نظرات',
        'add_to_cart' => 'افزودن به سبد خرید',
    ],

    'register' => [
        'hello' => 'خوش آمدید',
        'theme_name' => '👋 Xylo-Theme',
        'signup_now' => 'ایجاد حساب کاربری مشتری',
        'signup_description' => 'ثبت‌نام کنید تا خرید را آغاز کنید، سفارشات خود را پیگیری کنید، محصولات مورد علاقه‌تان را ذخیره کنید و به پیشنهادات ویژه دسترسی داشته باشید.',
        'copyright' => '© 2025 Xylo-Theme. کلیه حقوق محفوظ است.',
        'welcome_back' => 'بیایید شروع کنیم',
        'form_subtitle' => 'برای ایجاد حساب خرید، اطلاعات خود را وارد کنید.',
        'name' => 'نام و نام خانوادگی',
        'email' => 'آدرس ایمیل',
        'password' => 'رمز عبور',
        'confirm_password' => 'تأیید رمز عبور',
        'signup_btn' => 'ایجاد حساب',
        'already_account' => 'قبلاً حساب دارید؟',
        'login_here' => 'وارد شوید',
    ],

    'login' => [
        'hello' => 'خوش آمدید دوباره',
        'theme_name' => '👋 Xylo-Theme',
        'login_now' => 'وارد حساب کاربری خود شوید',
        'login_description' => 'برای مدیریت سفارشات، لیست علاقه‌مندی‌ها و دریافت تجربه خرید شخصی وارد شوید.',
        'copyright' => '© 2025 Xylo-Theme. کلیه حقوق محفوظ است.',
        'welcome_back' => 'خوشحالیم دوباره شما را می‌بینیم',
        'form_subtitle' => 'لطفاً برای ادامه اطلاعات ورود خود را وارد کنید.',
        'email' => 'آدرس ایمیل',
        'password' => 'رمز عبور',
        'login_btn' => 'ورود',
        'dont_have_account' => 'حساب ندارید؟',
        'signup' => 'ایجاد حساب',
        'forgot_password' => 'رمز عبور را فراموش کرده‌اید؟',
    ],
];
