<?php

return [
    'types' => [
        'promotion' => 'Promotion',
        'sale' => 'Sale',
        'seasonal' => 'Seasonal',
        'featured' => 'Featured',
        'announcement' => 'Announcement',
    ],
];
