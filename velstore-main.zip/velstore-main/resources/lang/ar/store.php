<?php

return [
    'header' => [
        'top_bar_message' => 'شحن مجاني للطلبات التي تزيد عن 50 دولارًا | الدعم | دليل المتاجر',
        'search_placeholder' => 'ابحث عن منتج',
    ],

    'footer' => [
        'account' => 'الحساب',
        'my_account' => 'حسابي',
        'wishlist' => 'قائمة الرغبات',
        'pages' => 'الصفحات',
        'privacy_policy' => 'سياسة الخصوصية',
        'terms_of_service' => 'شروط الخدمة',
        'follow_us' => 'تابعنا',
        'footer_logo_alt' => 'شعار ذيل صفحة فيلستور',
        'copyright' => '© 2025 متجر فيلستور التجريبي. جميع الحقوق محفوظة.',
        'powered_by' => 'بدعم من فيلستور لابز',
    ],

    'home' => [
        'banner_text' => 'اكتشف أكبر مجموعة من الأحذية الرياضية والأحذية وصيحات أزياء الشوارع.',
        'shop_now' => 'تسوق الآن',
        'explore_popular_categories' => 'استكشف الفئات الشائعة',
        'trending_products' => 'المنتجات الرائجة',
        'reviews' => 'المراجعات',
        'product_name_not_available' => 'اسم المنتج غير متاح',
        'featured_products' => 'المنتجات المميزة',
        'view_all' => 'عرض الكل',
        // Why Choose Us section
        'why_choose_us' => 'لماذا نحن؟',
        'fast_delivery_title' => 'توصيل سريع',
        'fast_delivery_text' => 'نقوم بتسليم طلباتك بسرعة وأمان حتى باب منزلك.',
        'customer_support_title' => 'دعم العملاء',
        'customer_support_text' => 'فريق الدعم لدينا متواجد دائمًا لمساعدتك في أي وقت وأي مكان.',
        'trusted_worldwide_title' => 'موثوق عالميًا',
        'trusted_worldwide_text' => 'آلاف العملاء الراضين، وتقييمات ممتازة، وتصنيفات عالية.',
        'ten_years_services_title' => 'خدمة منذ 10 سنوات',
        'ten_years_services_text' => 'أكثر من 10 سنوات من الخدمة الموثوقة وتقديم الجودة والرضا.',
    ],

    'product_detail' => [
        'color' => 'اللون',
        'size' => 'المقاس',
        'home' => 'الرئيسية',
        'in_stock' => 'متوفر في المخزون',
        'out_of_stock' => 'غير متوفر في المخزون',
        'customer_reviews' => 'آراء العملاء',
        'no_reviews' => 'لا توجد مراجعات لهذا المنتج بعد.',
        'no_review_text' => 'لم تتم كتابة أي مراجعة.',
        'average_rating' => 'متوسط التقييم',
        'days_ago' => '{1} قبل :days يوم|[2,*] قبل :days أيام',
        'description' => 'الوصف',
        'reviews' => 'المراجعات',
        'add_to_cart' => 'أضف إلى السلة',
        'increase_quantity' => 'زيادة الكمية',
        'decrease_quantity' => 'تقليل الكمية',
        'selected_variant_not' => 'المتغير المحدد غير متوفر.',
        'fetch_variant_failed' => 'تعذر جلب سعر المتغير.',
        'ajax_error' => 'حدث خطأ ما. يرجى المحاولة مرة أخرى.',
        'currency_symbol' => 'العملة',
        'cart_success' => 'تمت إضافة المنتج إلى السلة بنجاح.',
        'cart_update_error' => 'تعذر تحديث السلة. يرجى المحاولة مرة أخرى.',
        'submit_review_title' => 'أضف تقييمك',
        'review_optional' => 'التقييم (اختياري)',
        'submit_review_btn' => 'إرسال التقييم',
        'please' => 'يرجى',
        'login' => 'تسجيل الدخول',
        'customer' => 'العميل',
        'submit' => 'لتقديم تقييم.',
        'no_reviews_yet' => 'لا توجد تقييمات لهذا المنتج بعد.',
        'no_review_text' => 'لا يوجد نص للتقييم.',
        'day' => 'يوم',
        'days' => 'أيام',
        'ago' => 'منذ',
        'average_rating' => 'متوسط التقييم',
        'variant_not_available' => 'الخيار المحدد غير متوفر.',
        'something_wrong' => 'حدث خطأ ما. يرجى المحاولة مرة أخرى.',
        'added_to_wishlist' => 'تمت الإضافة إلى المفضلة ❤️',
        'removed_from_wishlist' => 'تمت الإزالة من المفضلة 💔',
        'login_to_wishlist' => 'يرجى تسجيل الدخول لإدارة المفضلة.',
        'review_already_submitted' => 'لقد قمت بتقييم هذا المنتج بالفعل.',
        'review_success' => 'شكراً لك! تم نشر تقييمك بنجاح.',
    ],

    'shop' => [
        'brands' => 'الماركات',
        'categories' => 'الفئات',
        'price' => 'السعر',
        'colors' => 'الألوان',
        'size' => 'المقاس',
        'red' => 'أحمر',
        'black' => 'أسود',
        'M' => 'متوسط',
        'L' => 'كبير',
        'price_range' => 'من :min إلى :max',
        'added_to_cart' => 'تمت إضافة المنتج إلى السلة بنجاح!',
    ],

    'cart' => [

        // Breadcrumb
        'breadcrumb_home' => 'الصفحة الرئيسية',
        'breadcrumb_cart' => 'عربة التسوق',

        // Cart messages
        'empty_cart' => 'سلة التسوق فارغة.',
        'continue_shopping' => 'متابعة التسوق',
        'update_cart' => 'تحديث السلة',

        // Table headings
        'product' => 'المنتج',
        'price' => 'السعر',
        'quantity' => 'الكمية',
        'subtotal' => 'المجموع الفرعي',

        // Cart totals section
        'cart_totals' => 'إجمالي السلة',
        'subtotal_label' => 'المجموع الفرعي',
        'discount_label' => 'الخصم',
        'total_label' => 'الإجمالي',
        'proceed_to_checkout' => 'إتمام الشراء',

        // Coupon section
        'coupon_heading' => 'قسيمة الخصم',
        'coupon_placeholder' => 'رمز القسيمة',
        'apply_coupon' => 'تطبيق القسيمة',
        'remove_coupon' => 'إزالة القسيمة',

        // Toast messages
        'coupon_applied' => 'تم تطبيق القسيمة بنجاح!',
        'coupon_removed' => 'تمت إزالة القسيمة بنجاح!',
        'cart_updated' => 'تم تحديث السلة بنجاح!',
        'item_removed' => 'تمت إزالة العنصر من السلة.',
        'error_occurred' => 'حدث خطأ ما. يرجى المحاولة مرة أخرى.',
        'product_removed' => 'تمت إزالة المنتج من السلة.',
    ],

    'checkout' => [

        // Breadcrumb
        'breadcrumb_home' => 'الصفحة الرئيسية',
        'breadcrumb_category' => 'سماعة الرأس',
        'breadcrumb_checkout' => 'إتمام الطلب',

        // Section titles
        'shipping_information' => 'معلومات الشحن',
        'contact_information' => 'معلومات الاتصال',
        'payment_method' => 'طريقة الدفع',
        'order_summary' => 'ملخص الطلب',

        // Shipping form placeholders
        'first_name' => 'الاسم الأول',
        'last_name' => 'اسم العائلة',
        'address' => 'العنوان',
        'suite' => 'الشقة / الطابق',
        'select_country' => 'اختر الدولة',
        'city' => 'المدينة',
        'select_state' => 'اختر الولاية',
        'zipcode' => 'الرمز البريدي',
        'use_as_billing' => 'استخدام كعنوان الفاتورة',

        // Contact form placeholders
        'email' => 'البريد الإلكتروني',
        'phone' => 'رقم الهاتف',

        // Payment
        'select_payment' => 'اختر طريقة الدفع',
        'stripe' => 'سترايب',
        'paypal' => 'باي بال',

        // Summary labels
        'subtotal' => 'المجموع الفرعي',
        'shipping' => 'الشحن',
        'shipping_info' => 'أدخل عنوانك لعرض تكلفة الشحن',
        'total' => 'الإجمالي',
        'proceed' => 'متابعة',
        'place_order' => 'تأكيد الطلب',

        // Toast / messages
        'order_success' => 'تم إرسال طلبك بنجاح!',
        'order_failed' => 'حدث خطأ ما. يرجى المحاولة مرة أخرى.',
        'payment_required' => 'يرجى اختيار طريقة الدفع قبل المتابعة.',
        'paypal_instructions' => 'يرجى إتمام الدفع باستخدام زر باي بال.',
    ],

    'profile' => [
        'title' => 'تعديل الملف الشخصي',
        'choose_file' => 'اختر ملفًا',
        'name' => 'الاسم',
        'email' => 'البريد الإلكتروني',
        'phone' => 'رقم الهاتف',
        'address' => 'العنوان',
        'current_password' => 'كلمة المرور الحالية',
        'new_password' => 'كلمة المرور الجديدة',
        'confirm_new_password' => 'تأكيد كلمة المرور الجديدة',
        'save' => 'حفظ',
        'success' => 'نجاح',
        'profile_updated' => 'تم تحديث الملف الشخصي بنجاح.',
    ],

    'category' => [
        'home' => 'الرئيسية',
        'min_price' => 'أقل سعر',
        'max_price' => 'أعلى سعر',
        'sort_by' => 'ترتيب حسب',
        'newest' => 'الأحدث',
        'price_low_high' => 'السعر: من الأقل إلى الأعلى',
        'price_high_low' => 'السعر: من الأعلى إلى الأقل',
        'top_rated' => 'الأعلى تقييماً',
        'filter' => 'تصفية',
        'reviews' => 'التقييمات',
        'product_name_not_available' => 'اسم المنتج غير متوفر',
        'no_products_found' => 'لا توجد منتجات في هذه الفئة.',
        'add_to_cart_success' => 'تمت إضافة المنتج إلى السلة بنجاح!',
    ],

    'wishlist' => [
        'title' => 'قائمتي المفضلة',
        'empty' => 'قائمتك المفضلة فارغة.',
        'reviews' => 'التقييمات',
        'add_to_cart' => 'أضف إلى السلة',
    ],

    'register' => [
        'hello' => 'مرحبًا',
        'theme_name' => 'Xylo-Theme 👋 منصّة زيلو',
        'signup_now' => 'إنشاء حساب العميل',
        'signup_description' => 'قم بالتسجيل للبدء في التسوق، تتبّع طلباتك، حفظ عناصر المفضلة، والحصول على عروض حصرية.',
        'copyright' => '© 2025 Xylo-Theme. جميع الحقوق محفوظة.',
        'welcome_back' => 'لنبدأ الآن',
        'form_subtitle' => 'يرجى إدخال بياناتك لإنشاء حساب التسوق.',
        'name' => 'الاسم الكامل',
        'email' => 'البريد الإلكتروني',
        'password' => 'كلمة المرور',
        'confirm_password' => 'تأكيد كلمة المرور',
        'signup_btn' => 'إنشاء حساب',
        'already_account' => 'هل لديك حساب بالفعل؟',
        'login_here' => 'تسجيل الدخول من هنا',
    ],

    'login' => [
        'hello' => 'مرحبًا بعودتك',
        'theme_name' => 'Xylo-Theme 👋 منصّة زيلو',
        'login_now' => 'تسجيل الدخول إلى حسابك',
        'login_description' => 'قم بتسجيل الدخول لإدارة طلباتك، حفظ مفضلاتك، والاستمتاع بتجربة تسوق مخصصة.',
        'copyright' => '© 2025 Xylo-Theme. جميع الحقوق محفوظة.',
        'welcome_back' => 'سعداء برؤيتك مرة أخرى',
        'form_subtitle' => 'يرجى إدخال بيانات تسجيل الدخول للمتابعة.',
        'email' => 'البريد الإلكتروني',
        'password' => 'كلمة المرور',
        'login_btn' => 'تسجيل الدخول',
        'dont_have_account' => 'ليس لديك حساب؟',
        'signup' => 'إنشاء حساب',
        'forgot_password' => 'نسيت كلمة المرور؟',
    ],
];
