<?php

return [
    'header' => [
        'top_bar_message' => 'Бесплатная доставка при заказах на сумму более $50 | Поддержка | Поиск магазинов',
        'search_placeholder' => 'Поиск продукта',
    ],

    'footer' => [
        'account' => 'Аккаунт',
        'my_account' => 'Мой аккаунт',
        'wishlist' => 'Список желаемого',
        'pages' => 'Страницы',
        'privacy_policy' => 'Политика конфиденциальности',
        'terms_of_service' => 'Условия обслуживания',
        'follow_us' => 'Подписывайтесь на нас',
        'footer_logo_alt' => 'Логотип подвала Velstore',
        'copyright' => '© 2025 Velstore Demo. Все права защищены.',
        'powered_by' => 'Разработано Velstore Labs',
    ],

    'home' => [
        'banner_text' => 'Откройте для себя самое большое разнообразие кроссовок, обуви и уличной моды.',
        'shop_now' => 'Купить сейчас',
        'explore_popular_categories' => 'Изучите популярные категории',
        'trending_products' => 'Популярные товары',
        'reviews' => 'Отзывы',
        'product_name_not_available' => 'Название продукта недоступно',
        'featured_products' => 'Рекомендуемые товары',
        'view_all' => 'Посмотреть все',
        // Why Choose Us section
        'why_choose_us' => 'Почему выбирают нас?',
        'fast_delivery_title' => 'Быстрая доставка',
        'fast_delivery_text' => 'Мы быстро и безопасно доставляем ваши заказы прямо к вашему порогу.',
        'customer_support_title' => 'Поддержка клиентов',
        'customer_support_text' => 'Наша команда поддержки всегда готова помочь вам в любое время и в любом месте.',
        'trusted_worldwide_title' => 'Доверие по всему миру',
        'trusted_worldwide_text' => 'Тысячи довольных клиентов, отличные отзывы и высокие рейтинги.',
        'ten_years_services_title' => '10 лет работы',
        'ten_years_services_text' => 'Более 10 лет предоставляем надежный сервис, качество и удовлетворение.',
    ],

    'product_detail' => [
        'color' => 'Цвет',
        'size' => 'Размер',
        'home' => 'Главная',
        'in_stock' => 'В НАЛИЧИИ',
        'out_of_stock' => 'НЕТ В НАЛИЧИИ',
        'customer_reviews' => 'Отзывы покупателей',
        'no_reviews' => 'Для этого товара пока нет отзывов.',
        'no_review_text' => 'Отзыв не написан.',
        'average_rating' => 'Средний рейтинг',
        'days_ago' => '{1} :days день назад|[2,*] :days дней назад',
        'description' => 'Описание',
        'reviews' => 'Отзывы',
        'add_to_cart' => 'Добавить в корзину',
        'increase_quantity' => 'Увеличить количество',
        'decrease_quantity' => 'Уменьшить количество',
        'selected_variant_not' => 'Выбранный вариант недоступен.',
        'fetch_variant_failed' => 'Не удалось получить цену варианта.',
        'ajax_error' => 'Произошла ошибка. Пожалуйста, попробуйте снова.',
        'currency_symbol' => 'Валюта',
        'cart_success' => 'Товар успешно добавлен в корзину.',
        'cart_update_error' => 'Не удалось обновить корзину. Пожалуйста, попробуйте снова.',
        'submit_review_title' => 'Оставить отзыв',
        'review_optional' => 'Отзыв (необязательно)',
        'submit_review_btn' => 'Отправить отзыв',
        'please' => 'Пожалуйста',
        'login' => 'Войти',
        'customer' => 'Покупатель',
        'submit' => 'чтобы оставить отзыв.',
        'no_reviews_yet' => 'Для этого товара пока нет отзывов.',
        'no_review_text' => 'Отзыв не написан.',
        'day' => 'день',
        'days' => 'дней',
        'ago' => 'назад',
        'average_rating' => 'Средний рейтинг',
        'variant_not_available' => 'Выбранный вариант недоступен.',
        'something_wrong' => 'Что-то пошло не так. Пожалуйста, попробуйте снова.',
        'added_to_wishlist' => 'Добавлено в избранное ❤️',
        'removed_from_wishlist' => 'Удалено из избранного 💔',
        'login_to_wishlist' => 'Пожалуйста, войдите, чтобы управлять избранным.',
        'review_already_submitted' => 'Вы уже оставили отзыв на этот товар.',
        'review_success' => 'Спасибо! Ваш отзыв опубликован.',
    ],

    'shop' => [
        'brands' => 'Бренды',
        'categories' => 'Категории',
        'price' => 'Цена',
        'colors' => 'Цвета',
        'size' => 'Размер',
        'red' => 'Красный',
        'black' => 'Черный',
        'M' => 'Средний',
        'L' => 'Большой',
        'price_range' => ':min - :max',
        'added_to_cart' => 'Товар успешно добавлен в корзину!',
    ],

    'cart' => [

        // Breadcrumb
        'breadcrumb_home' => 'Главная',
        'breadcrumb_cart' => 'Корзина',

        // Cart messages
        'empty_cart' => 'Ваша корзина пуста.',
        'continue_shopping' => 'Продолжить покупки',
        'update_cart' => 'Обновить корзину',

        // Table headings
        'product' => 'Товар',
        'price' => 'Цена',
        'quantity' => 'Количество',
        'subtotal' => 'Промежуточный итог',

        // Cart totals section
        'cart_totals' => 'Итог корзины',
        'subtotal_label' => 'Промежуточный итог',
        'discount_label' => 'Скидка',
        'total_label' => 'Итого',
        'proceed_to_checkout' => 'Перейти к оформлению',

        // Coupon section
        'coupon_heading' => 'Купон',
        'coupon_placeholder' => 'Код купона',
        'apply_coupon' => 'Применить купон',
        'remove_coupon' => 'Удалить купон',

        // Toast messages
        'coupon_applied' => 'Купон успешно применён!',
        'coupon_removed' => 'Купон успешно удалён!',
        'cart_updated' => 'Корзина успешно обновлена!',
        'item_removed' => 'Товар удалён из корзины.',
        'error_occurred' => 'Произошла ошибка. Пожалуйста, попробуйте ещё раз.',
        'product_removed' => 'Товар удалён из корзины.',
    ],

    'checkout' => [

        // Breadcrumb
        'breadcrumb_home' => 'Главная страница',
        'breadcrumb_category' => 'Наушники',
        'breadcrumb_checkout' => 'Оформление заказа',

        // Section titles
        'shipping_information' => 'Информация о доставке',
        'contact_information' => 'Контактная информация',
        'payment_method' => 'Способ оплаты',
        'order_summary' => 'Сводка заказа',

        // Shipping form placeholders
        'first_name' => 'Имя',
        'last_name' => 'Фамилия',
        'address' => 'Адрес',
        'suite' => 'Квартира/Этаж',
        'select_country' => 'Выберите страну',
        'city' => 'Город',
        'select_state' => 'Выберите штат/регион',
        'zipcode' => 'Почтовый индекс',
        'use_as_billing' => 'Использовать как платежный адрес',

        // Contact form placeholders
        'email' => 'Электронная почта',
        'phone' => 'Телефон',

        // Payment
        'select_payment' => 'Выберите способ оплаты',
        'stripe' => 'Stripe',
        'paypal' => 'PayPal',

        // Summary labels
        'subtotal' => 'Промежуточный итог',
        'shipping' => 'Доставка',
        'shipping_info' => 'Введите свой адрес, чтобы увидеть стоимость доставки',
        'total' => 'Итого',
        'proceed' => 'Продолжить',
        'place_order' => 'Разместить заказ',

        // Toast / messages
        'order_success' => 'Ваш заказ успешно оформлен!',
        'order_failed' => 'Что-то пошло не так. Пожалуйста, попробуйте еще раз.',
        'payment_required' => 'Пожалуйста, выберите способ оплаты перед продолжением.',
        'paypal_instructions' => 'Пожалуйста, завершите оплату с помощью кнопки PayPal.',
    ],

    'profile' => [
        'title' => 'Редактировать профиль',
        'choose_file' => 'Выбрать файл',
        'name' => 'Имя',
        'email' => 'Электронная почта',
        'phone' => 'Телефон',
        'address' => 'Адрес',
        'current_password' => 'Текущий пароль',
        'new_password' => 'Новый пароль',
        'confirm_new_password' => 'Подтвердить новый пароль',
        'save' => 'Сохранить',
        'success' => 'Успешно',
        'profile_updated' => 'Профиль успешно обновлен.',
    ],

    'category' => [
        'home' => 'Главная',
        'min_price' => 'Минимальная цена',
        'max_price' => 'Максимальная цена',
        'sort_by' => 'Сортировать по',
        'newest' => 'Новинки',
        'price_low_high' => 'Цена: по возрастанию',
        'price_high_low' => 'Цена: по убыванию',
        'top_rated' => 'Лучшие по рейтингу',
        'filter' => 'Фильтр',
        'reviews' => 'Отзывы',
        'product_name_not_available' => 'Название товара недоступно',
        'no_products_found' => 'В этой категории товары не найдены.',
        'add_to_cart_success' => 'Товар успешно добавлен в корзину!',
    ],

    'wishlist' => [
        'title' => 'Мой список желаний',
        'empty' => 'Ваш список желаний пуст.',
        'reviews' => 'Отзывы',
        'add_to_cart' => 'Добавить в корзину',
    ],

    'register' => [
        'hello' => 'Добро пожаловать',
        'theme_name' => 'Xylo-Theme 👋',
        'signup_now' => 'Создать учетную запись клиента',
        'signup_description' => 'Зарегистрируйтесь, чтобы начать покупки, отслеживать заказы, сохранять избранное и получать эксклюзивные предложения.',
        'copyright' => '© 2025 Xylo-Theme. Все права защищены.',
        'welcome_back' => 'Давайте начнём',
        'form_subtitle' => 'Введите ваши данные, чтобы создать учётную запись.',
        'name' => 'Полное имя',
        'email' => 'Адрес электронной почты',
        'password' => 'Пароль',
        'confirm_password' => 'Подтвердите пароль',
        'signup_btn' => 'Создать аккаунт',
        'already_account' => 'Уже есть аккаунт?',
        'login_here' => 'Войти здесь',
    ],

    'login' => [
        'hello' => 'С возвращением',
        'theme_name' => 'Xylo-Theme 👋',
        'login_now' => 'Войдите в свой аккаунт',
        'login_description' => 'Войдите, чтобы управлять заказами, списком желаний и пользоваться персонализированным сервисом.',
        'copyright' => '© 2025 Xylo-Theme. Все права защищены.',
        'welcome_back' => 'Рады снова вас видеть',
        'form_subtitle' => 'Введите ваши данные для входа, чтобы продолжить.',
        'email' => 'Адрес электронной почты',
        'password' => 'Пароль',
        'login_btn' => 'Войти',
        'dont_have_account' => 'Нет аккаунта?',
        'signup' => 'Создать аккаунт',
        'forgot_password' => 'Забыли пароль?',
    ],
];
