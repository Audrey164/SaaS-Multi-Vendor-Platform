import './bootstrap';
// If you're using jQuery and DataTables, make sure those are also included
import $ from 'jquery';
import 'datatables.net';
import './admin/sidebar';

// If you want the DataTables default styling, you can import the CSS file
// import 'datatables.net-dt/css/jquery.dataTables.min.css'; // Uncomment if you need DataTables CSS


